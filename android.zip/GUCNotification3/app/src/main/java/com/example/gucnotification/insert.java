package com.example.gucnotification;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

public class insert extends AppCompatActivity {
    EditText username;
    EditText password;
    EditText title1;
    EditText content1;
    EditText date1;

    String user;
    String pass;

    RequestQueue queue1;
    boolean ok = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insertion);



        final Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submit();
            }
        });


    }

    public void submit() {
        queue1 = Volley.newRequestQueue(getApplicationContext());

        String url = "http://192.168.99.100:5000/api/users/getAllUsers";

        StringRequest sRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject reader;
                        JSONObject tempObj;

                        username = findViewById(R.id.username);
                        password = findViewById(R.id.password);

                        String u = username.getText().toString();
                        String p = password.getText().toString();
                        try {
                            reader = new JSONObject(response);
                            JSONArray array = reader.getJSONArray("users");
                            for (int i = 0; i < array.length(); i++) {
                                tempObj = array.getJSONObject(i);
                                user = tempObj.getString("username");
                                pass = tempObj.getString("password");
                                System.out.println("THIS IS THE USEER" + user);

                                if (user.equals(u)) {
                                    if (pass.equals(p)) {
                                        ahmos();
                                        break;
                                    }
                                }

                            }

                        } catch (JSONException e) {
                            System.out.println("7ABIBTAK FEL SAYF 7ABITAK FE SHETAAAA ESHTAAAA YA SAYYYF ESHTA YA SHETAAA");
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("3ALA BALIII HABIBI 3ALA BALIIII LEH YA MASRY LAAA W LAAA LAAA W 1000 LAAA");
                error.printStackTrace();
            }
        });
        queue1.add(sRequest);
    }

    public void ahmos(){
        System.out.println("ANA MALEEET A DEBUG BUG BUG");



            title1 = findViewById(R.id.title);
            content1 = findViewById(R.id.content);
            date1 = findViewById(R.id.date);

            String title = title1.getText().toString();
            String content = content1.getText().toString();
            String date = date1.getText().toString();

            try {



                String url2 = "http://192.168.99.100:5000/api/notifications/getAllNotifications";
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

                JSONObject jsonBody = new JSONObject();
                jsonBody.put("title", title);
                jsonBody.put("content", content);
                jsonBody.put("date", date);
                final String requestBody = jsonBody.toString();

                JsonObjectRequest jsonobj = new JsonObjectRequest(Request.Method.POST, url2,jsonBody,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                System.out.println("7 HABABIIIB ESTHABEBNAHOM MN 3AND EL MESTHABEBEEEN YAWAD YA MEHABEB YA MESTHABEB ESTHABEBLENA 7 HABAIB");
                                String res = response.toString();
                                System.out.println(res);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                System.out.println("CLOCKSSS CLOCKSSSS ");
                                error.printStackTrace();
                            }


                        });

                requestQueue.add(jsonobj);
            } catch (JSONException e) {
                System.out.println(" eroooor ");

                e.printStackTrace();
            }
        }
    }

