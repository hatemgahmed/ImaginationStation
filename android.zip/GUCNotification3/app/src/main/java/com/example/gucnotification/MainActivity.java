package com.example.gucnotification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listview ;
    Context app;
    TextView textview;
    TextView test;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        app = this;

        Intent intent = getIntent();


        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(loginActivity.app);
        if (acct != null) {
            String personName = acct.getDisplayName();
            String personEmail = acct.getEmail();
            String personId = acct.getId();


            textview = findViewById(R.id.text2);
            textview.setText("Hello, " + personName);

            test = findViewById(R.id.text);
        }

        final Button signout = findViewById(R.id.signout);

        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signOut();
            }
        });

        final Button insert = findViewById(R.id.insert);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertion();
            }
        });
    }

    public void onClickThis(View view)
    {
        test.setText("clicked ya Ahmos");

        DatePicker datePicker;
        datePicker = (DatePicker) findViewById(R.id.date);

        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth() +1;
        int year =  datePicker.getYear();

        final String date = year + "-" + month + "-" + day +"T00:00:00.000Z" ;

        listview = (ListView) findViewById(R.id.listView);
        final ArrayList<String> list = new ArrayList<String>();
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());

        String url ="http://192.168.99.100:5000/api/notifications/getAllNotifications";

        StringRequest sRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println("FULL ELFULL W 100 EL 100");

                        JSONObject reader;
                        JSONObject tempObj;
                        String title;
                        String content;
                        String description;
                        String dateIn;
                        try {
                            reader = new JSONObject(response);
                            JSONArray array= reader.getJSONArray("notification");
                            for(int i=0; i<array.length();i++){
                                tempObj =array.getJSONObject(i);
                                title= tempObj.getString("title");
                                content= tempObj.getString("content");
                                dateIn = tempObj.getString("date");

                                if(date.equals(dateIn)){
                                    list.add(title+" "+content);
                                    //slist.add("succ" + title);

                                    final ArrayAdapter adapter = new ArrayAdapter(app,
                                            android.R.layout.simple_list_item_1, list);
                                    listview.setAdapter(adapter);

                                }
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            System.out.println("7ABIBTAK FEL SAYF 7ABITAK FE SHETAAAA ESHTAAAA YA SAYYYF ESHTA YA SHETAAA");
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("3ALA BALIII HABIBI 3ALA BALIIII LEH YA MASRY LAAA W LAAA LAAA W 1000 LAAA");
                error.printStackTrace();
            }
        });
        queue.add(sRequest);


    }

    private void signOut() {
        loginActivity.mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent intent = new Intent(app, loginActivity.class);
                        startActivity(intent);
                    }
                });
    }
    public   void insertion()
    {
        try {
            Intent i = new Intent(getApplicationContext(),  insert.class);
            startActivity(i);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }
}

